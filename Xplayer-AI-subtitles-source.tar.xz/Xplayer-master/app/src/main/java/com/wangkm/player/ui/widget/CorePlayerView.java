package com.wangkm.player.ui.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

import com.wangkm.exo.media.core.ExoPlayerFactory;
import com.wangkm.ijk.media.core.IjkPlayerFactory;
import com.wangkm.player.R;
import com.wangkm.widget.WidgetFactory;
import com.wangkm.xplayer.base.AbstractMediaPlayer;
import com.wangkm.xplayer.listener.OnPlayerEventListener;
import com.wangkm.xplayer.media.IMediaPlayer;
import com.wangkm.xplayer.widget.VideoPlayer;


/**
 * created by wangkm
 * Desc:支持解码器交互的简单播放器封装交互组件
 */
public class CorePlayerView extends LinearLayout {

    private static final String PATH = "https://vd3.bdstatic.com/mda-pd736fppd4m1muub/sc/cae_h264/1680924082856978562/mda-pd736fppd4m1muub.mp4";//惊奇队长2预告
    protected VideoPlayer mVideoPlayer;
    private int mCurrentMediaCore;//当前正在使用的解码器类型 0:系统 1:ijk 2:exo
    private String mUrl;

    public CorePlayerView(Context context) {
        this(context, null);
    }

    public CorePlayerView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CorePlayerView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        View.inflate(context, R.layout.view_player_core, this);
        mVideoPlayer = findViewById(R.id.view_video_player);
        findViewById(R.id.view_player_container).getLayoutParams().height = getResources().getDisplayMetrics().widthPixels * 9 / 16;//给播放器固定一个高度
        WidgetFactory.INSTANCE.bindDefaultControls(mVideoPlayer.initController());//不显示返回按钮\不添加悬浮窗窗口交互UI组件
        mVideoPlayer.setOnPlayerActionListener(new OnPlayerEventListener() {
            @Override
            public AbstractMediaPlayer createMediaPlayer() {
                if (1 == mCurrentMediaCore) {
                    return IjkPlayerFactory.create().createPlayer(getContext());//IJK解码器
                } else if (2 == mCurrentMediaCore) {
                    return ExoPlayerFactory.create().createPlayer(getContext());//EXO解码器
                } else {
                    return null;//播放器内部默认的
                }
            }
        });
        OnClickListener onClickListener = new OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = view.getId();
                if (id == R.id.view_core_1) {
                    if(0!=mCurrentMediaCore){
                        findViewById(R.id.view_core_1).setSelected(true);
                        findViewById(R.id.view_core_2).setSelected(false);
                        findViewById(R.id.view_core_3).setSelected(false);
                        mCurrentMediaCore = 0;
                        rePlay();
                    }
                } else if (id == R.id.view_core_2) {
                    if(1!=mCurrentMediaCore){
                        findViewById(R.id.view_core_1).setSelected(false);
                        findViewById(R.id.view_core_2).setSelected(true);
                        findViewById(R.id.view_core_3).setSelected(false);
                        mCurrentMediaCore = 1;
                        rePlay();
                    }
                } else if (id == R.id.view_core_3) {
                    if(2!=mCurrentMediaCore){
                        findViewById(R.id.view_core_1).setSelected(false);
                        findViewById(R.id.view_core_2).setSelected(false);
                        findViewById(R.id.view_core_3).setSelected(true);
                        mCurrentMediaCore = 2;
                        rePlay();
                    }
                }

            }
        };
        mCurrentMediaCore=0;
        findViewById(R.id.view_core_1).setSelected(true);
        findViewById(R.id.view_core_1).setOnClickListener(onClickListener);
        findViewById(R.id.view_core_2).setOnClickListener(onClickListener);
        findViewById(R.id.view_core_3).setOnClickListener(onClickListener);
    }

    /**
     * 重新播放
     */
    private void rePlay() {
        if (null != mVideoPlayer) {
            mVideoPlayer.onReset();
            mVideoPlayer.setLoop(false);
            mVideoPlayer.setZoomModel(IMediaPlayer.MODE_ZOOM_CROPPING);
            mVideoPlayer.setProgressCallBackSpaceTime(300);
            mVideoPlayer.getController().setTitle("测试播放地址");//视频标题(默认视图控制器横屏可见)
            mVideoPlayer.setDataSource(TextUtils.isEmpty(mUrl)? PATH :mUrl);//播放地址设置
            mVideoPlayer.prepareAsync();//开始异步准备播放
        }
    }

    public void onResume() {
        if (null != mVideoPlayer) mVideoPlayer.onResume();
    }

    public void onPause() {
        if (null != mVideoPlayer) mVideoPlayer.onPause();
    }

    public boolean isBackPressed() {
        if (null != mVideoPlayer) {
            if (mVideoPlayer.isBackPressed()) {
                return true;
            }
            return false;
        }
        return true;
    }

    public void onDestroy() {
        if (null != mVideoPlayer) mVideoPlayer.onDestroy();
    }

    public void start(String url) {
        if (null != mVideoPlayer) {
            this.mUrl=url;
            mVideoPlayer.setLoop(false);
            mVideoPlayer.setZoomModel(IMediaPlayer.MODE_ZOOM_CROPPING);
            mVideoPlayer.setProgressCallBackSpaceTime(300);
            mVideoPlayer.getController().setTitle("测试播放地址");//视频标题(默认视图控制器横屏可见)
            mVideoPlayer.setDataSource(TextUtils.isEmpty(url)? PATH :url);//播放地址设置
            mVideoPlayer.prepareAsync();//开始异步准备播放
        }
    }
}