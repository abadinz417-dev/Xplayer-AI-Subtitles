package com.wangkm.player.ai

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/**
 * AI智能字幕生成处理器
 * 功能：
 * 1. 从视频文件提取音频
 * 2. 使用AI语音识别生成字幕
 * 3. 支持多语言翻译
 * 4. 字幕时间轴同步
 */
class SubtitleAIProcessor(private val context: Context) {
    
    companion object {
        private const val TAG = "SubtitleAIProcessor"
    }
    
    data class SubtitleItem(
        val startTime: Long,        // 开始时间(毫秒)
        val endTime: Long,          // 结束时间(毫秒)
        val text: String,           // 字幕文本
        val confidence: Float = 1.0f // 识别置信度
    )
    
    data class SubtitleConfig(
        val sourceLanguage: String = "zh-CN",     // 源语言
        val targetLanguage: String? = null,       // 目标翻译语言
        val maxSegmentDuration: Long = 10000,     // 最大片段时长(毫秒)
        val enablePunctuation: Boolean = true,    // 启用标点符号
        val enableTimestamps: Boolean = true      // 启用时间戳
    )
    
    /**
     * 从视频文件生成AI字幕
     */
    suspend fun generateSubtitles(
        videoPath: String,
        config: SubtitleConfig = SubtitleConfig()
    ): Result<List<SubtitleItem>> = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "开始为视频生成字幕: $videoPath")
            
            // 1. 提取音频文件
            val audioFile = extractAudioFromVideo(videoPath)
                ?: return@withContext Result.failure(Exception("音频提取失败"))
            
            // 2. 使用AI语音识别
            val rawTranscription = performSpeechRecognition(audioFile, config)
            
            // 3. 处理时间轴同步
            val subtitles = processTimestamps(rawTranscription, config)
            
            // 4. 翻译处理(如果需要)
            val finalSubtitles = if (config.targetLanguage != null) {
                translateSubtitles(subtitles, config.sourceLanguage, config.targetLanguage)
            } else {
                subtitles
            }
            
            // 清理临时文件
            audioFile.delete()
            
            Log.d(TAG, "字幕生成完成，共${finalSubtitles.size}条字幕")
            Result.success(finalSubtitles)
            
        } catch (e: Exception) {
            Log.e(TAG, "字幕生成失败", e)
            Result.failure(e)
        }
    }
    
    /**
     * Extract the first audio track to a standard 16-bit PCM WAV file.
     * MediaCodec is used here so no separate FFmpeg executable is required.
     */
    private suspend fun extractAudioFromVideo(videoPath: String): File? = withContext(Dispatchers.IO) {
        val inputFile = File(videoPath)
        if (!inputFile.exists()) return@withContext null

        val outputFile = File(context.cacheDir, "xplayer_audio_${System.currentTimeMillis()}.wav")
        val extractor = MediaExtractor()
        var decoder: android.media.MediaCodec? = null
        try {
            extractor.setDataSource(videoPath)
            var audioTrack = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    audioTrack = i
                    format = f
                    break
                }
            }
            if (audioTrack < 0 || format == null) throw IOException("No audio track found")

            extractor.selectTrack(audioTrack)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: throw IOException("Unknown audio format")
            decoder = android.media.MediaCodec.createDecoderByType(mime)
            decoder.configure(format, null, null, 0)
            decoder.start()

            val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val pcm = java.io.ByteArrayOutputStream()
            val info = android.media.MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val inputBuffer = decoder.getInputBuffer(inputIndex)!!
                        inputBuffer.clear()
                        val size = extractor.readSampleData(inputBuffer, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0L, android.media.MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                when (val outputIndex = decoder.dequeueOutputBuffer(info, 10_000)) {
                    android.media.MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> Unit
                    android.media.MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    else -> if (outputIndex >= 0) {
                        if (info.size > 0) {
                            val outputBuffer = decoder.getOutputBuffer(outputIndex)!!
                            val chunk = ByteArray(info.size)
                            outputBuffer.position(info.offset)
                            outputBuffer.limit(info.offset + info.size)
                            outputBuffer.get(chunk)
                            pcm.write(chunk)
                        }
                        decoder.releaseOutputBuffer(outputIndex, false)
                        if ((info.flags and android.media.MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            outputDone = true
                        }
                    }
                }
            }

            writeWav(outputFile, pcm.toByteArray(), sampleRate, channels, 16)
            outputFile
        } catch (e: Exception) {
            Log.e(TAG, "Audio extraction failed", e)
            outputFile.delete()
            null
        } finally {
            try { decoder?.stop() } catch (_: Exception) {}
            try { decoder?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }
    }

    private fun writeWav(file: File, pcm: ByteArray, sampleRate: Int, channels: Int, bits: Int) {
        val byteRate = sampleRate * channels * bits / 8
        val blockAlign = channels * bits / 8
        java.io.DataOutputStream(java.io.BufferedOutputStream(file.outputStream())).use { out ->
            fun leInt(v: Int) { out.write(byteArrayOf((v and 0xff).toByte(), ((v shr 8) and 0xff).toByte(), ((v shr 16) and 0xff).toByte(), ((v shr 24) and 0xff).toByte())) }
            fun leShort(v: Int) { out.write(byteArrayOf((v and 0xff).toByte(), ((v shr 8) and 0xff).toByte())) }
            out.writeBytes("RIFF"); leInt(36 + pcm.size); out.writeBytes("WAVE")
            out.writeBytes("fmt "); leInt(16); leShort(1); leShort(channels); leInt(sampleRate); leInt(byteRate); leShort(blockAlign); leShort(bits)
            out.writeBytes("data"); leInt(pcm.size); out.write(pcm)
        }
    }

    /**
     * Run local Whisper. The model is downloaded once to app-private storage.
     * There is no cloud API or per-minute charge.
     */
    private suspend fun performSpeechRecognition(
        audioFile: File,
        config: SubtitleConfig
    ): List<RawTranscription> = withContext(Dispatchers.IO) {
        val modelDir = File(context.getExternalFilesDir("models") ?: context.filesDir, "whisper")
        modelDir.mkdirs()
        val modelFile = File(modelDir, "ggml-base.bin")
        if (!modelFile.exists() || modelFile.length() < 50_000_000L) {
            downloadWhisperModel(modelFile)
        }

        val model = dev.ffmpegkit.whisper.Whisper.loadModel(context, modelFile.absolutePath)
        try {
            val result = dev.ffmpegkit.whisper.Whisper.transcribe(
                model,
                audioFile.absolutePath,
                dev.ffmpegkit.whisper.WhisperConfig(language = config.sourceLanguage.substringBefore('-'))
            )
            result.segments.map { segment ->
                RawTranscription(segment.startMs, segment.endMs, segment.text.trim(), 1.0f)
            }.filter { it.text.isNotBlank() }
        } finally {
            dev.ffmpegkit.whisper.Whisper.releaseModel(model)
        }
    }

    private fun downloadWhisperModel(target: File) {
        val url = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin?download=true"
        val request = okhttp3.Request.Builder().url(url).build()
        val client = okhttp3.OkHttpClient()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Whisper model download failed: HTTP ${response.code}")
            val body = response.body ?: throw IOException("Empty Whisper model response")
            val temp = File(target.parentFile, target.name + ".part")
            body.byteStream().use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
            if (!temp.renameTo(target)) throw IOException("Could not save Whisper model")
        }
    }

    /**
     * 处理时间轴同步
     */
    private fun processTimestamps(
        rawTranscriptions: List<RawTranscription>,
        config: SubtitleConfig
    ): List<SubtitleItem> {
        return rawTranscriptions.map { raw ->
            SubtitleItem(
                startTime = raw.startTime,
                endTime = raw.endTime,
                text = if (config.enablePunctuation) addPunctuation(raw.text) else raw.text,
                confidence = raw.confidence
            )
        }
    }
    
    /**
     * 翻译字幕
     */
    private suspend fun translateSubtitles(
        subtitles: List<SubtitleItem>,
        sourceLanguage: String,
        targetLanguage: String
    ): List<SubtitleItem> = withContext(Dispatchers.IO) {
        // 这里集成翻译API，如Google Translate, DeepL等
        // 为了演示，返回模拟翻译结果
        
        val translationMap = mapOf(
            "欢迎使用智能播放器" to "Welcome to Smart Player",
            "这里是AI生成的字幕功能演示" to "This is AI-generated subtitle feature demo",
            "支持多种语言识别和翻译" to "Supports multiple language recognition and translation"
        )
        
        subtitles.map { subtitle ->
            subtitle.copy(
                text = translationMap[subtitle.text] ?: subtitle.text
            )
        }
    }
    
    /**
     * 添加标点符号
     */
    private fun addPunctuation(text: String): String {
        // 简单的标点符号处理逻辑
        return when {
            text.endsWith("吗") || text.endsWith("呢") -> "$text？"
            text.contains("！") || text.contains("。") -> text
            else -> "$text。"
        }
    }
    
    /**
     * 导出字幕文件
     */
    suspend fun exportSubtitles(
        subtitles: List<SubtitleItem>,
        outputPath: String,
        format: SubtitleFormat = SubtitleFormat.SRT
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val outputFile = File(outputPath)
            val content = when (format) {
                SubtitleFormat.SRT -> generateSRTContent(subtitles)
                SubtitleFormat.VTT -> generateVTTContent(subtitles)
                SubtitleFormat.ASS -> generateASSContent(subtitles)
            }
            
            outputFile.writeText(content, Charsets.UTF_8)
            Log.d(TAG, "字幕文件导出成功: $outputPath")
            Result.success(outputFile)
            
        } catch (e: Exception) {
            Log.e(TAG, "字幕文件导出失败", e)
            Result.failure(e)
        }
    }
    
    /**
     * 生成SRT格式字幕内容
     */
    private fun generateSRTContent(subtitles: List<SubtitleItem>): String {
        return subtitles.mapIndexed { index, subtitle ->
            val startTime = formatSRTTime(subtitle.startTime)
            val endTime = formatSRTTime(subtitle.endTime)
            "${index + 1}\n$startTime --> $endTime\n${subtitle.text}\n"
        }.joinToString("\n")
    }
    
    /**
     * 生成VTT格式字幕内容
     */
    private fun generateVTTContent(subtitles: List<SubtitleItem>): String {
        val header = "WEBVTT\n\n"
        val content = subtitles.map { subtitle ->
            val startTime = formatVTTTime(subtitle.startTime)
            val endTime = formatVTTTime(subtitle.endTime)
            "$startTime --> $endTime\n${subtitle.text}\n"
        }.joinToString("\n")
        return header + content
    }
    
    /**
     * 生成ASS格式字幕内容
     */
    private fun generateASSContent(subtitles: List<SubtitleItem>): String {
        val header = """
            [Script Info]
            Title: AI Generated Subtitles
            ScriptType: v4.00+
            
            [V4+ Styles]
            Format: Name, Fontname, Fontsize, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
            Style: Default,Arial,20,0,0,0,0,100,100,0,0,1,2,0,2,10,10,10,1
            
            [Events]
            Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
            
        """.trimIndent()
        
        val content = subtitles.map { subtitle ->
            val startTime = formatASSTime(subtitle.startTime)
            val endTime = formatASSTime(subtitle.endTime)
            "Dialogue: 0,$startTime,$endTime,Default,,0,0,0,,${subtitle.text}"
        }.joinToString("\n")
        
        return header + content
    }
    
    /**
     * 格式化SRT时间格式
     */
    private fun formatSRTTime(milliseconds: Long): String {
        val totalSeconds = milliseconds / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        val ms = milliseconds % 1000
        return "%02d:%02d:%02d,%03d".format(hours, minutes, seconds, ms)
    }
    
    /**
     * 格式化VTT时间格式
     */
    private fun formatVTTTime(milliseconds: Long): String {
        return formatSRTTime(milliseconds).replace(',', '.')
    }
    
    /**
     * 格式化ASS时间格式
     */
    private fun formatASSTime(milliseconds: Long): String {
        val totalSeconds = milliseconds / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        val centiseconds = (milliseconds % 1000) / 10
        return "%d:%02d:%02d.%02d".format(hours, minutes, seconds, centiseconds)
    }
    
    // 内部数据类
    private data class RawTranscription(
        val startTime: Long,
        val endTime: Long,
        val text: String,
        val confidence: Float
    )
    
    enum class SubtitleFormat {
        SRT, VTT, ASS
    }
}